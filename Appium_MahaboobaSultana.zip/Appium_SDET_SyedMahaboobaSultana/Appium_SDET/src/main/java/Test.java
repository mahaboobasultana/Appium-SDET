package com.ibm.viewpointe.ocs.testcases;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ibm.viewpointe.ocs.base.AccessTokenGeneration;
import com.ibm.viewpointe.ocs.base.TestBase;
import com.ibm.viewpointe.ocs.exceptions.ConfigException;
import com.ibm.viewpointe.ocs.utilities.XLUtils;

public class CreateRegistryEntry extends TestBase{ 	
	
	public static Logger logger=Logger.getLogger(CreateRegistryEntry.class);	
	@SuppressWarnings("unused")
	private String testName, contentMetaDataField, contentTagsField, contentTags, tagsField, tags, contentMetaData, samlUserId, testCaseId,  requestInfoField, usageField, usage,participantsField,npIdField,npId,entityIdField,entityId,contentObjectField,expectedCountField, expectedCount,objectField, locationField,  location,  labelField,  label,  contentTypeField,  contentType,  sizeField,  size,  contentField,  content,checkSumField,checkSum,  urlField,url,  webServicePayloadField,  webServicePayload, requestingNPIdField,requestingNPId,requestingEntityIdField, requestingEntityId,metaDataField, metaData, expRequestStatus,  expRegistryStatus,  expErrorCode,  expInternalErrorMessage;
	public String dbRegistryId, dbRegistryIdSignature, dbRrgistered, dbErrorMessage, query, repositoryFolder, regRepositoryFolder,repRepositoryFolder, storagePathPrefix, storagePathSignature,storageFolderLevel, dbRegistered;
	public int dbStatusCode,minAccessDays;
	public boolean returnOCSData, returnInternalMessage, replicationSenderDone, initialRegValidation;
	public Date expiryDate, currentDate, accessDate;
	public ExtentHtmlReporter htmlReporter;
	public ExtentReports extent;
	public ExtentTest parentTest, childTest, test;
	public JSONArray participantArray=new JSONArray();
	public JSONObject metaDataObj,contentMetaDataObj;
	
	
	@BeforeTest
	 public void setExtent() throws ClassNotFoundException, SQLException, IOException, ConfigException {
		getSiteDetails();
		Class.forName(driver); 
		connObj1=DriverManager.getConnection(originatingSiteDbUrl,originatingSiteDbUser,originatingSiteDbPassword);
		connObj2=DriverManager.getConnection(replicationSiteDbUrl,replicationSiteDbUser,replicationSiteDbPassword);
//		connObj3=DriverManager.getConnection(replicationSenderSiteDbUrl,replicationSenderSiteDbUser,replicationSenderSiteDbPassword);
        //connObj1=DBConnection19c.makeDBConnection();
		stmt1=connObj1.createStatement();
		//connObj2=DBConnection19c2.makeDBConnection();
		stmt2=connObj2.createStatement();
		//connObj3=DBConnection.makeDBConnection();
		//stmt3=connObj3.createStatement();
		currentDate=new Date();
		// specify location of the report
		htmlReporter = new ExtentHtmlReporter(createRegistryReportName);
		htmlReporter.config().setDocumentTitle("OCS Automation Report"); // Title of report
		htmlReporter.config().setReportName("CreateRegistryEntry - Functional Testing"); // Name of the report
		htmlReporter.config().setTheme(Theme.DARK);
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
	  
		// Passing General information
		extent.setSystemInfo("Project Name", "OCS");
		extent.setSystemInfo("Web Service", "CreateRegistryEntry");
		extent.setSystemInfo("Host Name", "Softlayer-Demo");
		extent.setSystemInfo("Environment", "DEV");
	 }


	
	@Test(dataProvider="CreateRegistryEntryTestData")
	public void createRegistryEntryRequest(String testCaseId, String testName, String samlUserId, String requestInfoField, String usageField, String usage, String participantsField, String npIdField, String npId, String entityIdField, String entityId, String contentObjectField, String expectedCountField, String expectedCount, String objectField,String locationField, String location, String labelField, String label, String contentTypeField, String contentType, String sizeField, String size, String contentField, String content, String contentMetaDataField, String contentMetaData, String contentTagsField, String contentTags, String checkSumField, String checkSum, String urlField, String url, String webServicePayloadField, String webServicePayload,String requestingNPIdField,String requestingNPId,String requestingEntityIdField,String requestingEntityId,String metaDataField,String metaData, String tagsField, String tags, String expRequestStatus, String expRegistryStatus, String expErrorCode, String expInternalErrorMessage) throws SQLException, InterruptedException, ParseException{
		returnInternalMessage=false;
		returnOCSData=false;
		replicationSenderDone=false;
		repositoryFolder=null;
		initialRegValidation=false;
		this.testCaseId = testCaseId;
		this.testName = testName;
		parentTest=extent.createTest(testCaseId+"_"+testName);
		logger.info("*****************************************************************************");
		logger.info("*****************************************************************************");
		logger.info(testName);
		
		this.samlUserId = samlUserId;
		this.requestInfoField = requestInfoField;
		this.usageField=usageField;
		this.usage=usage;
		this.participantsField=participantsField;
		this.npIdField=npIdField;
		this.npId=npId;
		this.entityIdField=entityIdField;
		this.entityId=entityId;
		this.contentObjectField = contentObjectField;
		this.expectedCountField = expectedCountField;
		this.expectedCount = expectedCount;
		this.objectField=objectField;
		this.locationField = locationField;
		this.location = location;
		this.labelField = labelField;
		this.label = label;
		this.contentTypeField = contentTypeField;
		this.contentType = contentType;
		this.sizeField = sizeField;
		this.size = size;
		this.contentField = contentField;
		this.content = content;
		this.contentMetaDataField=contentMetaDataField;
		this.contentMetaData=contentMetaData;
		this.contentTagsField=contentTagsField;
		this.contentTags=contentTags;
		this.checkSumField = checkSumField;
		this.checkSum=checkSum;
		this.urlField = urlField;
		this.url = url;
		this.webServicePayloadField = webServicePayloadField;
		this.webServicePayload = webServicePayload;
		this.requestingNPIdField=requestingNPIdField;
		this.requestingNPId=requestingNPId;
		this.requestingEntityIdField=requestingEntityIdField;
		this.requestingEntityId=requestingEntityId;
		this.metaDataField=metaDataField;
		this.metaData=metaData;	
		this.tagsField=tagsField;
		this.tags=tags;
		//System.out.println(tags.length());
		this.expRequestStatus = expRequestStatus;
		this.expRegistryStatus = expRegistryStatus;
		this.expErrorCode = expErrorCode;
		this.expInternalErrorMessage = expInternalErrorMessage;
		
		stmt=stmt1;
		getDatabseInputsBeforeRequest();
		postInputRequest();	
		
		childTest=parentTest.createNode("Response Validation");
		validateResponse();		
		
		childTest=parentTest.createNode("Metrics Table Data Validation");
		validateMetricsTable();
		//if(expRequestStatus.equals("Success") && returnInternalMessage==true &&  !expRegistryStatus.equals("WaitingForContent") && returnOCSData==true){
		if(expRequestStatus.equals("Success") &&  !expRegistryStatus.equals("WaitingForContent") && returnOCSData==true){
			childTest=parentTest.createNode("Primary Database Validation");
			query="select * from Registrations order by RECORDID desc fetch first row only";
			logger.info("Started Primary Database Validation");
			validateRegistrationsTables(query);
			Thread.sleep(10000);
			reg_Replication_Validation();
			Thread.sleep(10000);
			reg_ServicesToApply_Validation();
			logger.info("Primary Database validation is successful");
			
			childTest=parentTest.createNode("OCSData Validation");
			validateOCSData();
			
			Thread.sleep(10000);
			
			stmt=stmt2;
			childTest=parentTest.createNode("Replicated Database Validation");
			query="select * from Registrations where registryId="+'\''+dbRegistryId+ '\'';
			logger.info("Started Replicated Database Validation");
			validateRegistrationsTables(query);
			reg_Replication_Validation();
			logger.info("Replicated Database validation is successful");
		}
	
		/*if(expRequestStatus.equals("Success")){
			childTest=parentTest.createNode(originatingSite+" Primary Database Validation");
			query="select * from Registrations order by RECORDID desc fetch first row only";
			//logger.info("Started "+originatingSite+" Primary Database Validation");
			//InitialRegValidation=true;
			validateRegistrationsTables(query);
			reg_Replication_Validation();
			//logger.info(originatingSite+" Primary Database validation is successful");
			
			
			
			stmt=stmt2;
			childTest=parentTest.createNode(replicationSite+" ONCS Replicated Database Validation");
			Query="select * from Registrations where registryId="+'\''+dbRegistryId+ '\'';
			//logger.info("Started "+replicationSite+" ONCS Replicated Database Validation");
			validateRegistrationsTables(Query);	
			//logger.info(replicationSite+" ONCS Replicated Database validation is successful");

			stmt=stmt3;
			//ChildTest=ParentTest.createNode(replicationSendersite+" ReplicationSender Replicated Database Validation");
			
			//Thread.sleep(10000);			

			////logger.info("Started "+replicationSendersite+" ReplicationSender Replicated Database Validation");
			//validateRegistrationsTables(Query);
			////logger.info(replicationSendersite+" ReplicationSender Replicated Database validation is successful");
			
			if (ReplicationSenderDone){
				validateRegistrationsTables(Query);
				//logger.info("ONCS and ReplicationSender replicatied database validation is sucessful");
			}
			else{
				//logger.info("ONCS replicatied database validation is sucessful but ReplicationSender replication is not done");
				Assert.assertTrue(false);
			}*/

			//validateRegistrationsTables(Query);
			//logger.info("ONCS and ReplicationSender replicatied database validation is sucessful");
		
			
		/*	if(expRegistryStatus.equals("Registered") && returnOCSData==true){
				childTest=parentTest.createNode("OCSData Validation");
				validateOCSData();
			}
		

		//logger.info("####Ended "+testCaseId+"_"+testName+"####");*/
		}
		
	public void getDatabseInputsBeforeRequest() throws SQLException{
			//logger.info("Started fetching the prerequisite data from the Database");
	        ResultSet rscount =stmt.executeQuery("select count(*) from Metrics_CreateRegistryEntry");
	        rscount.next();
	        rowCountBeforeSendingRequest=rscount.getInt("count(*)");
	        
			//logger.info("Metrics count fetched before sending request: "+ rowCountBeforeSendingRequest);	        
	        ResultSet rsInternalMsg =stmt.executeQuery("select SAMLUSERID from NETWORKPARTICIPANTS_SAMLUSERIDS where SAMLUSERID="+'\''+samlUserId+ '\''+" AND NPKEY IN (select RECORDID from NETWORKPARTICIPANTS where RETURNINTERNALMESSAGE='TRUE')");
        	result=rsInternalMsg.next();
        	if(result){
        			if(rsInternalMsg.getString("SAMLUSERID").equals(samlUserId)){
        				returnInternalMessage=true;
        		}
        	}
        	
        	logger.info("ReturnInternalMessage: "+ returnInternalMessage);

	        if(expRequestStatus.equals("Success")){
	        	ResultSet rsStatus =stmt.executeQuery("select STATUSNUMBER from STATUSES where STATUS="+'\''+expRegistryStatus+ '\'');
	        	rsStatus.next();
	        	dbStatusCode=rsStatus.getInt("STATUSNUMBER");
	        	
	        	ResultSet rsOCSData =stmt.executeQuery("select SAMLUSERID from NETWORKPARTICIPANTS_SAMLUSERIDS where SAMLUSERID="+'\''+samlUserId+ '\''+" AND NPKEY IN (select RECORDID from NETWORKPARTICIPANTS where OCSDATASTATUSES = "+'\''+dbStatusCode+ '\''+" or OCSDATASTATUSES like "+'\''+dbStatusCode+",%' or OCSDATASTATUSES like '%,"+dbStatusCode+ '\''+")");
	        	result=rsOCSData.next();
	        	if(result){
	        			if(rsOCSData.getString("SAMLUSERID").equals(samlUserId)){
	        				returnOCSData=true;
	        		}
	        	}
	        	
	        	//logger.info("ReturnOCSData: "+returnOCSData);
       		        
	        }
	        
	        if(expRequestStatus.equals("Failed")){
		        ResultSet rsErrorMessage =stmt.executeQuery("select EXTERNALMESSAGE from ERRORMESSAGES where MESSAGENUMBER="+expErrorCode);
		        rsErrorMessage.next();
		        dbErrorMessage=rsErrorMessage.getString("EXTERNALMESSAGE");
		        
		        if(expInternalErrorMessage.contains("%%REQUESTINGNPID%%")){
		        	expInternalErrorMessage=expInternalErrorMessage.replace("%%REQUESTINGNPID%%", requestingNPId.toLowerCase());
		        }
	        }
	        
	        //logger.info("Completed fetching prerequisite data from the database");
	}
	
	public void postInputRequest(){
		//logger.info("Started preparing the JSON input request from the Excel row");
		inputRequest = new JSONObject();
		RestAssured.baseURI=URI;
		httpRequest=RestAssured.given();
		
		
		
		if(!requestInfoField.equals("")){			
			JSONObject requestInfoObj=new JSONObject();
			if(!usageField.equals("")){
				if(usage.equals("null")){
					requestInfoObj.put(usageField, null);
				}else{
					requestInfoObj.put(usageField, usage);
				}
			}
			if(usage.equals("null") || usage.equals("")){
				usage="PROD";
			}
			inputRequest.put(requestInfoField,requestInfoObj);			
		}
		
		
		
		if(!requestingNPIdField.equals("")){
			if(requestingNPId.equals("null")){
				inputRequest.put(requestingNPIdField,null);
			}else{
				inputRequest.put(requestingNPIdField,requestingNPId);
			}
		}
		
		if(!requestingEntityIdField.equals("")){
			if(requestingEntityId.equals("null")){
				inputRequest.put(requestingEntityIdField,null);
			}else{
				inputRequest.put(requestingEntityIdField,requestingEntityId);
			}
		}
		if(!metaDataField.equals("")){
			if(!metaData.equals("NA")){
				if(metaData.equals("null")){
					inputRequest.put(metaDataField,null);
				}else{
					metaDataObj=new JSONObject();
					String key,value;
					if(!metaData.equals("")){
						String keyValuePairs[]=metaData.split(",");
						for(int i=0;i<keyValuePairs.length;i++){
							String keyValues[]=keyValuePairs[i].split(":");
							if(keyValues.length==0){
								metaDataObj.put("","");
							}
							else{
								key=keyValues[0];
								if(keyValues.length==1){
									metaDataObj.put(key,"");
								}
								else{
									value=keyValues[1];
									if(value.equals("null")){
										metaDataObj.put(key, null);
									}
									else{						
										metaDataObj.put(key, value);
									}
								}
							}
						}					
					}
					inputRequest.put(metaDataField,metaDataObj);				
				}			
			}else{
				metaData=null;
			}
		}
		
		if(!tagsField.equals("")){
			if(!tags.equals("NA")){	
				if(tags.equals("null")){
					inputRequest.put(tagsField, null);
				}else{
					inputRequest.put(tagsField, tags);
				}
			}else{
				tags=null;
			}
		}
		
		/*if(!participantsField.equals("")){
			String npIds[]=npId.split(",");
			String entityIds[]=entityId.split(",");
			System.out.println(npIds.length+" sfgfdgf "+entityIds.length);
			JSONArray participantsArray= new JSONArray(); 
			for(int i=0;i<npIds.length && !npIds[0].equals("");i++){
				for(int j=0;j<entityIds.length && !entityIds[0].equals("");j++){
					JSONObject participantObject=new JSONObject();
					if(i==j){
						if(!npIds[i].equals("NA")){
							if(!npIds[i].equals("INVALID")){
								participantObject.put(npIdField, npIds[i]);
							}
							else{
								participantObject.put("nId", npIds[i]);
							}
						}
							
						if(!npIds[i].equals("NA")){
							if(!npIds[i].equals("INVALID")){
								participantObject.put(entityIdField, entityIds[j]);
							}
							else{
								participantObject.put("entiyId", entityIds[j]);
							}
						}
						participantsArray.add(participantObject);
					}
				}
			}
			inputRequest.put(participantsField,participantsArray);
		}*/
		
	/*	if(!participantsField.equals("")){
			JSONArray participantsArray= new JSONArray(); 
			JSONObject participantObject=new JSONObject();
			String[] npIds = null,entityIds = null;
			Boolean npIdBlank, entityIdBlank;
			if(!npIdField.equals("")){
				if(!npId.equals("null")){
					if(!npId.equals("")){
						npIds=npId.split(",");
					}
					else{
						participantObject.put(npIdField, "");
					}
				}
				else{
					participantObject.put(npIdField, null);
				}
			}
			if(!entityIdField.equals("")){
				if(!entityId.equals("null")){
					if(!entityId.equals("")){
						entityIds=entityId.split(",");
					}
					else{
						participantObject.put(entityIdField, "");
					}
				}
				else{
					participantObject.put(entityIdField, null);
				}
			}
			if(!npId.equals("") && !entityId.equals("") && !npId.equals("null") && !entityId.equals("null")){
				for(int i=0;i<npIds.length;i++){
					for(int j=0;j<entityIds.length;j++){
						participantObject=new JSONObject();
						if(i==j){
							if(!npIds[i].equals("NA")){
								if(!npIds[i].equals("INVALID")){
									participantObject.put(npIdField, npIds[i]);
								}
								else{
									participantObject.put("nId", npIds[i]);
								}
							}
								
							if(!npIds[i].equals("NA")){
								if(!npIds[i].equals("INVALID")){
									participantObject.put(entityIdField, entityIds[j]);
								}
								else{
									participantObject.put("entiyId", entityIds[j]);
								}
							}
							//participantsArray.add(participantObject);
						}
					}
				}
			}
			
			participantsArray.add(participantObject);
			inputRequest.put(participantsField,participantsArray);
		}*/
		
		if(!participantsField.equals("")){
			String npIds[]=npId.split(",");
			String entityIds[]=entityId.split(",");
			JSONArray participantsArray= new JSONArray(); 
			for(int i=0;i<npIds.length;i++){
				for(int j=0;j<entityIds.length;j++){
					JSONObject participantObject=new JSONObject();
					if(i==j){
						participantObject.put(npIdField, npIds[i]);
						participantObject.put(entityIdField, entityIds[j]);
						participantsArray.add(participantObject);
					}
				}
			}
			participantArray=participantsArray;
			inputRequest.put(participantsField,participantsArray);
		}
		
		if(!contentObjectField.equals("")){
			JSONObject contentObj=new JSONObject();
			if(!expectedCountField.equals("")){
				if(expectedCount.equals("null")){
					contentObj.put(expectedCountField, null);
				}else{
					contentObj.put(expectedCountField, expectedCount);
				}
			}
			if(!objectField.equals("")){
				JSONObject objectObj=new JSONObject();
				if(!locationField.equals("")){
					if(location.equals("null")){
						objectObj.put(locationField, null);
					}else{
						objectObj.put(locationField, location);
					}
				}
				
				if(!labelField.equals("")){
					if(label.equals("null")){
						objectObj.put(labelField, null);
					}else{
						objectObj.put(labelField, label);
					}
				}
				
				if(!contentTypeField.equals("")){
					if(contentType.equals("null")){
						objectObj.put(contentTypeField, null);
					}else{
						objectObj.put(contentTypeField, contentType);
					}
				}	
				
				if(!sizeField.equals("")){
					if(!size.equals("NA")){
						if(size.equals("null")){
							objectObj.put(sizeField, null);
						}else{
							objectObj.put(sizeField, size);
						}
					}
				}
				
				if(!contentField.equals("")){
					if(!content.equals("NA")){	
						if(content.equals("null")){
							objectObj.put(contentField, null);
						}else{
							objectObj.put(contentField, content);
						}
					}
				}
				
				if(!contentMetaDataField.equals("")){
					if(!contentMetaData.equals("NA")){				
						if(contentMetaData.equals("null")){
							objectObj.put(contentMetaDataField,null);
						}else{
							contentMetaDataObj=new JSONObject();
							String key,value;
							if(!contentMetaData.equals("")){
								String keyValuePairs[]=contentMetaData.split(",");
								for(int i=0;i<keyValuePairs.length;i++){
									String keyValues[]=keyValuePairs[i].split(":");
									if(keyValues.length==0){
										contentMetaDataObj.put("","");
									}
									else{
										key=keyValues[0];
										if(keyValues.length==1){
											contentMetaDataObj.put(key,"");
										}
										else{
											value=keyValues[1];
											if(value.equals("null")){
											contentMetaDataObj.put(key, null);
											}
											else{						
												contentMetaDataObj.put(key, value);
											}
										}
									}					
								}				
							}
							objectObj.put(contentMetaDataField,contentMetaDataObj);				
						}			
					}else{
						contentMetaData=null;
					}
				}
					
				if(!contentTagsField.equals("")){
					if(!contentTags.equals("NA")){	
						if(contentTags.equals("null")){
							objectObj.put(contentTagsField, null);
						}else{
							objectObj.put(contentTagsField, contentTags);
						}
					}else{
						contentTags=null;
					}
				}
				
				
				if(!checkSumField.equals("")){
					if(!checkSum.equals("NA")){		
						if(checkSum.equals("null")){
							objectObj.put(checkSumField, null);
						}else{
							objectObj.put(checkSumField, checkSum);
						}
					}
				}
				
				if(!urlField.equals("")){
					if(!url.equals("NA")){		
						if(url.equals("null")){
							objectObj.put(urlField, null);
						}else{
							objectObj.put(urlField, url);
						}
					}
				}
				
				if(!webServicePayloadField.equals("")){
					if(!webServicePayload.equals("NA")){
						if(webServicePayload.equals("null")){
							objectObj.put(webServicePayloadField, null);
						}else{
							objectObj.put(webServicePayloadField, webServicePayload);
						}
					}
				}
				
				contentObj.put(objectField, objectObj);
			}
			inputRequest.put(contentObjectField,contentObj);
		}	
	
		httpRequest.header("Authorization", AccessTokenGeneration.getAccessToken(samlUserId));
		httpRequest.header("Content-Type","application/json");
		httpRequest.body(inputRequest.toString());
		logger.info(inputRequest.toString());
		
		response=httpRequest.request(Method.POST,"CreateRegistryEntry/");
		
		responseBody=response.getBody().asString();
		logger.info(responseBody);
	}
	
	public void validateResponse(){
		responseBody=response.getBody().asString();
		logger.info("Received JSON response: "+responseBody);
		logger.info("Started validating the response");
		Assert.assertTrue(responseBody!=null);
		JsonPath jsonPath = new JsonPath(responseBody);	
		
		Assert.assertEquals(true, jsonPath.getString("requestStatus").equals(expRequestStatus));
		if(expRequestStatus.equals("Success")){
			Assert.assertEquals(true, responseBody.contains("registryStatus"));
			Assert.assertEquals(true, responseBody.contains("requestStatus"));
			Assert.assertEquals(true, responseBody.contains("registryId"));
			Assert.assertEquals(true, responseBody.contains("registryIdSignature"));
			Assert.assertEquals(true, responseBody.contains("expirationDate"));
			Assert.assertEquals(false,responseBody.contains("error"));
		    Assert.assertEquals(true, jsonPath.getString("registryStatus").equals(expRegistryStatus));
			if(returnOCSData==true){
				if(!expRegistryStatus.equals("WaitingForContent")){
				Assert.assertEquals(true, responseBody.contains("ocsData"));
				}
			}
			else{
				Assert.assertEquals(false, responseBody.contains("ocsData"));
			}
		} else if(expRequestStatus.equals("Failed")){
				Assert.assertEquals(true,responseBody.contains("requestStatus"));
				Assert.assertEquals(false,responseBody.contains("ocsData"));
				Assert.assertEquals(true,responseBody.contains("error"));
				HashMap<String, String> errorMap = jsonPath.get("error");
				Assert.assertEquals(true ,errorMap.containsKey("code"));
				Assert.assertEquals(expErrorCode ,errorMap.get("code"));
				Assert.assertEquals(true, errorMap.containsKey("message"));
				Assert.assertEquals(dbErrorMessage, errorMap.get("message"));
				ArrayList<String> errorCodes = new ArrayList<String>();
				errorCodes.add("120");
				errorCodes.add("320");
				errorCodes.add("321");
				errorCodes.add("101");
				errorCodes.add("199");
				errorCodes.add("300");
 				if(returnInternalMessage==true || expErrorCode.equals("313")){
 					if(!errorCodes.contains(errorMap.get("code"))){
 						Assert.assertEquals(true, errorMap.containsKey("internalMessage"));
 						Assert.assertEquals(expInternalErrorMessage, errorMap.get("internalMessage"));
 					}else{
 						Assert.assertEquals(false, errorMap.containsKey("internalMessage"));
 					}
				} else{
					if(returnInternalMessage==false && !expErrorCode.equals("313")){
						Assert.assertEquals(false, errorMap.containsKey("internalMessage"));						
					}
				}
			}
		
		logger.info("Response validation is completed");
	}
	
	public void validateMetricsTable() throws SQLException{
		if(!expErrorCode.equals("300") && !expErrorCode.equals("101") && !expErrorCode.equals("313")){
			logger.info("Started validating the Database");
			logger.info("Started Metrics table validation");			
	        ResultSet rscount =stmt.executeQuery("select count(*) from Metrics_CreateRegistryEntry");
	        result=rscount.next();
			Assert.assertTrue(result);
	        Assert.assertEquals(rowCountBeforeSendingRequest+1, rscount.getInt("count(*)"));
			logger.info("Metrics table count validated successfully");			
	        ResultSet rsMetrics =stmt.executeQuery("select * from Metrics_CreateRegistryEntry order by RECORDID desc fetch first row only");
	        result=rsMetrics.next();
	        Assert.assertEquals(rsMetrics.getString("REGISTRYID"),new JsonPath(responseBody).getString("registryId"));
	        Assert.assertEquals(rsMetrics.getString("INTERNALOCSREQUEST"), "FALSE");
	        Assert.assertTrue(rsMetrics.getString("REQUESTINGNPID").equalsIgnoreCase(requestingNPId));
	        Assert.assertTrue(rsMetrics.getString("REQUESTINGENTITYID").equalsIgnoreCase(requestingEntityId));
	        Assert.assertEquals(rsMetrics.getString("STATUS"), new JsonPath(responseBody).getString("requestStatus"));
	        Assert.assertNotNull(rsMetrics.getString("IPADDRESS"));
	        Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsMetrics.getTimestamp("PROCESSSTARTED")));
	        Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsMetrics.getTimestamp("PROCESSENDED")));
	        Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsMetrics.getTimestamp("PINGSTARTED")));
	        Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsMetrics.getTimestamp("PINGENDED")));
	        Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsMetrics.getTimestamp("BUSINESSLOGICSTARTED")));
	        Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsMetrics.getTimestamp("BUSINESSLOGICENDED")));
	        if(expRequestStatus.equals("Failed")){
		        Assert.assertEquals(Integer.parseInt(expErrorCode), rsMetrics.getInt("ERRORNUMBER"));
		        Assert.assertEquals(expInternalErrorMessage, rsMetrics.getString("INTERNALERRORMESSAGE"));
	        }else{
	    	     Assert.assertEquals(0, rsMetrics.getInt("ERRORNUMBER"));
	    	     Assert.assertNull(rsMetrics.getString("INTERNALERRORMESSAGE"));
	        }
		    
		    logger.info("Metrics table content validated successfully");
		
		}
	}
	
	public void validateRegistrationsTables(String query) throws SQLException, ParseException{
		logger.info("Started Registrations table validation");	
		ResultSet res =  stmt.executeQuery("SELECT value from CONFIGURATION where configoption = 'minAccessDays'");
		res.next();
		minAccessDays = res.getInt("VALUE");
		if(usage.equals("TEST")){
			ResultSet resTest =  stmt.executeQuery("SELECT value from CONFIGURATION where configoption = 'minAccessDaysTest'");
			resTest.next();
			minAccessDays = resTest.getInt("VALUE");
	    }
		ResultSet res1 =  stmt.executeQuery("select value from configuration where configoption='storagePathPrefix'");
		res1.next();
		storagePathPrefix = res1.getString("VALUE");
		ResultSet res2 =  stmt.executeQuery("select value from configuration where configoption='storagePathSignature'");
		res2.next();
		storagePathSignature= res2.getString("VALUE");
		ResultSet res3 =  stmt.executeQuery("select value from configuration where configoption='storageFolderLevel'");
		res3.next();
		storageFolderLevel= res3.getString("VALUE");
	
	    ResultSet rsReg =stmt.executeQuery(query);
	    result=rsReg.next();
		Assert.assertTrue(result);
		Date regExpirationDate=rsReg.getTimestamp("EXPIRATIONDATE");
	    Assert.assertNotNull(rsReg.getString("REGISTRYID"));
	    Assert.assertNotNull(rsReg.getString("REGISTRYIDSIGNATURE"));
	    dbRegistryId=rsReg.getString("REGISTRYID");
	    dbRegistryIdSignature=rsReg.getString("REGISTRYIDSIGNATURE");
	    Assert.assertEquals(dbStatusCode, rsReg.getInt("STATUS"));
	    Assert.assertEquals(usage, rsReg.getString("USAGETYPE"));
	    Assert.assertNotNull(rsReg.getString("IPADDRESS"));
	    Assert.assertEquals(samlUserId, rsReg.getString("SAMLUSERID"));
	    Assert.assertNotNull(rsReg.getString("REPOSITORYFOLDER"));
	    Assert.assertEquals(minAccessDays, rsReg.getInt("MINACCESSDAYS"));
	    regRepositoryFolder=rsReg.getString("REPOSITORYFOLDER");
	    Assert.assertEquals(true, rsReg.getString("REPOSITORYFOLDER").contains(storagePathPrefix));
	    Assert.assertEquals(Integer.parseInt(expectedCount), rsReg.getInt("EXPECTEDCOUNT"));
	    Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsReg.getTimestamp("CREATED")));
	    Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsReg.getTimestamp("RECEIVED")));
	    if(expRegistryStatus.equals("Registered")){
	    	Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsReg.getTimestamp("REGISTERED")));
	    	dbRegistered=new SimpleDateFormat("YYYYMMddHHmmssSSS").format(rsReg.getTimestamp("REGISTERED"));
	    }
	    else{
	    	Assert.assertNull(rsReg.getTimestamp("REGISTERED"));
	    }
	    if(tagsField!=null && !tagsField.isEmpty() && tagsField.equals("tags") && tags!=null && !tags.isEmpty()){
	    	Assert.assertEquals(tags, rsReg.getString("TAGS"));
	    }else{
	    	Assert.assertNull(rsReg.getString("TAGS"));
	    }
	    /*if(tagsField.equals("tags") && !tags.equals("") && !tags.equals("null")){
	    	Assert.assertEquals(tags, rsReg.getString("TAGS"));
	    }
	    if(tags.equals("") || tags.equals("null")){
	    	Assert.assertNull(rsReg.getString("TAGS"));
	    }*/
	    if(metaDataField!=null && !metaDataField.isEmpty() && metaDataField.equals("metaData") && metaData!=null && !metaData.isEmpty()){
	    	Assert.assertEquals(metaDataObj.toString(), rsReg.getString("METADATA"));
	    }
	    Assert.assertNull(rsReg.getString("OWNEDBY"));
	    Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsReg.getTimestamp("UPDATED")));
	    Assert.assertEquals(originatingSite.substring(7), rsReg.getString("HOMESITE"));
	    
	    logger.info("Registrations table content validated successfully");
	    
	    logger.info("Started Registrations_contentobjects table validation");	
	    ResultSet rsRegContent =stmt.executeQuery("select * from Registrations_contentobjects where registryId="+'\''+dbRegistryId+ '\'');
	    result=rsRegContent.next();
	    Assert.assertTrue(result);	
	    Assert.assertEquals(location, rsRegContent.getString("LOCATION"));
	    Assert.assertEquals(contentType, rsRegContent.getString("TYPE"));
	    Assert.assertEquals(label, rsRegContent.getString("LABEL"));
	    Assert.assertEquals(1, rsRegContent.getInt("VERSION"));
	    Assert.assertEquals(1, rsRegContent.getInt("SEQUENCENUMBER"));
	    //Assert.assertEquals("Available", rsRegContent.getString("STATUS"));
	    if(contentTagsField!=null && !contentTagsField.isEmpty() && contentTagsField.equals("tags") && contentTags!=null && !contentTags.isEmpty()){
	    	Assert.assertEquals(contentTags, rsRegContent.getString("TAGS"));
	    }else{
	    	Assert.assertNull(rsRegContent.getString("TAGS"));
	    }
	    
	    /*if(contentTagsField.equals("tags") && !contentTags.equals("") && !contentTags.equals("null") ){
	    	Assert.assertEquals(contentTags, rsRegContent.getString("TAGS"));
	    }
	    if(contentTags.equals("") || contentTags.equals("null")){
	    	Assert.assertNull(rsRegContent.getString("TAGS"));
	    }
	   */
	    if(contentMetaDataField!=null && !contentMetaDataField.isEmpty() && contentMetaDataField.equals("metaData") &&  contentMetaData!=null && contentMetaData.isEmpty()){
	    	Assert.assertEquals(contentMetaDataObj.toString(), rsRegContent.getString("METADATA"));
	    }else{
	    	Assert.assertNull(rsRegContent.getString("METADATA"));
	    }
	    Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsRegContent.getTimestamp("RECEIVED")));
	    
	    if(location.equals("centralDataRepository")){
	    	Assert.assertNull(rsRegContent.getString("URL"));
	    	Assert.assertNull(rsRegContent.getString("WEBSERVICEPAYLOAD"));
	    	if(!contentType.equals("METADATA")){
	    		Assert.assertEquals(Integer.parseInt(size), rsRegContent.getInt("SIZE"));
		    	Assert.assertEquals(checkSum, rsRegContent.getString("CHECKSUM"));
	    		Assert.assertEquals("TRUE", rsRegContent.getString("CONTENTPROVIDED"));
	    	} else {
	    		Assert.assertEquals("FALSE", rsRegContent.getString("CONTENTPROVIDED"));
	    	}
	    }else if(location.equals("website")){
	    		Assert.assertEquals(0, rsRegContent.getInt("SIZE"));
	    		Assert.assertEquals(url, rsRegContent.getString("URL"));
	    		Assert.assertNull(rsRegContent.getString("CHECKSUM"));
	    		Assert.assertNull(rsRegContent.getString("WEBSERVICEPAYLOAD"));
	    		Assert.assertEquals("FALSE", rsRegContent.getString("CONTENTPROVIDED"));
	    } else {
	    		//Assert.assertEquals(Integer.parseInt(size), rsRegContent.getInt("SIZE"));
		    	Assert.assertEquals(checkSum, rsRegContent.getString("CHECKSUM"));
		    	Assert.assertEquals(url, rsRegContent.getString("URL"));
	    		if(url.contains("?payload=")){
	    			Assert.assertNull(rsRegContent.getString("WEBSERVICEPAYLOAD"));
	    		}else{
	    			Assert.assertEquals(webServicePayload, rsRegContent.getString("WEBSERVICEPAYLOAD"));
	    		}
	    		Assert.assertEquals("FALSE", rsRegContent.getString("CONTENTPROVIDED"));
	    	  }	    
		
	    logger.info("Registrations_contentobjects table content validated successfully");
	    logger.info("Started Registrations_Participants table data validation");		
	   	
	    ResultSet rsParticipantData = stmt.executeQuery("select * from REGISTRATIONS_PARTICIPANTS where registryId="+'\''+dbRegistryId+ '\''+" order by RECORDID asc");	
	    ArrayList<String> actualParticipantlist = new ArrayList<String>();
	    ArrayList<String> dbParticipantList = new ArrayList<String>();
	    for(int i=0;i<participantArray.size();i++){
	    	JSONObject object = (JSONObject) participantArray.get(i);
	    	String str = object.get("npId").toString().toLowerCase()+"_"+object.get("entityId").toString().toLowerCase();
	    	actualParticipantlist.add(str);
		}
	    JSONArray jsonarray=new JSONArray();
	    while(rsParticipantData.next()){
	    	JSONObject obj=new JSONObject();
	    	obj.put("type",rsParticipantData.getString("TYPE"));
	    	obj.put("npId",rsParticipantData.getString("NPID"));
	    	obj.put("entityId",rsParticipantData.getString("ENTITYID"));
	    	obj.put("accessDate",new SimpleDateFormat("yyyy-MM-dd").format(rsParticipantData.getTimestamp("ACCESSDATE")));
	    	obj.put("additionalNPDays",rsParticipantData.getInt("ADDITIONALNPDAYS"));
	    	obj.put("additionalDays",rsParticipantData.getInt("ADDITIONALDAYS"));
	    	obj.put("created",new SimpleDateFormat("yyyy-MM-dd").format(rsParticipantData.getTimestamp("CREATED")));
	    	
	    	jsonarray.add(obj);
	    }
	    for(int i=0;i<jsonarray.size();i++){
	    	JSONObject object=(JSONObject) jsonarray.get(i);
	    	
	    	ResultSet npData = stmt.executeQuery("select * from NETWORKPARTICIPANTS where ID="+'\''+object.get("npId").toString().toUpperCase()+ '\'');
	    	npData.next();
	    	int additionalAccessDaysOriginating=npData.getInt("ADDITIONALACCESSDAYSORIGINATING");
	    	int additionalAccessDaysReceiving=npData.getInt("ADDITIONALACCESSDAYSRECEIVING");
	    	ResultSet entityData = stmt.executeQuery("select * from NETWORKPARTICIPANTS_ADDITIONALDAYS where npkey="+'\''+npData.getInt("RECORDID")+ '\'');	
	    	boolean recordPresent= entityData.next();
	    	Calendar c1 = Calendar.getInstance();
	    	Calendar c2 = Calendar.getInstance();
		    c1.setTime(currentDate);
		    c2.setTime(currentDate);
		    int count=0;
	    	if(object.get("type").equals("Originator")){
		    	Assert.assertTrue(requestingNPId.equalsIgnoreCase(object.get("npId").toString()));
		    	Assert.assertTrue(requestingEntityId.equalsIgnoreCase(object.get("entityId").toString()));
		    	Assert.assertEquals(object.get("additionalNPDays"), additionalAccessDaysOriginating);
			    if(recordPresent){
			    	do{
			    		if(entityData.getString("ENTITYID").toLowerCase().equals(object.get("entityId"))){
				    		c1.add(Calendar.DATE, (minAccessDays+additionalAccessDaysOriginating+entityData.getInt("ORIGINATINGDAYS")));
				    		Assert.assertEquals(object.get("additionalDays"), entityData.getInt("ORIGINATINGDAYS"));
				    		count++;
				    	}
			    	}while(entityData.next());
			    	if(count==0){
			    		c1.add(Calendar.DATE, (minAccessDays+additionalAccessDaysOriginating+0));
			    	}
			    }else{
			    	c1.add(Calendar.DATE, (minAccessDays+additionalAccessDaysOriginating+0));
			    	Assert.assertEquals(object.get("additionalDays"), 0);
			    }
			    
			    
	    	}else{
	    		dbParticipantList.add(object.get("npId")+"_"+object.get("entityId"));
	    		Assert.assertEquals("Recipient", object.get("type"));
	    		Assert.assertEquals(object.get("additionalNPDays"), additionalAccessDaysReceiving);
			    if(recordPresent){
			    	do{
				    	if(entityData.getString("ENTITYID").equals(object.get("entityId"))){
				    		c1.add(Calendar.DATE, (minAccessDays+additionalAccessDaysReceiving+entityData.getInt("RECEIVINGDAYS")));
				    		Assert.assertEquals(object.get("additionalDays"), entityData.getInt("RECEIVINGDAYS"));
				    		count++;
				    	}
				    }while(entityData.next());
			    	if(count==0){
			    		c1.add(Calendar.DATE, (minAccessDays+additionalAccessDaysReceiving+0));
			    	}
			    }else{
			    	c1.add(Calendar.DATE, (minAccessDays+additionalAccessDaysReceiving+0));
			    	Assert.assertEquals(object.get("additionalDays"), 0);
			    }
	    		
	    	}
	    	if(usage.equals("TEST")){
	    		c2.add(Calendar.DATE, minAccessDays);
	    		Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(c2.getTime()), object.get("accessDate"));
	    		accessDate=new SimpleDateFormat("yyyy-MM-dd").parse((String) object.get("accessDate"));
	    	}else{
	    		Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(c1.getTime()), object.get("accessDate"));
	    		if(accessDate==null){
					accessDate=new SimpleDateFormat("yyyy-MM-dd").parse((String) object.get("accessDate"));
				}else{
					if(accessDate.compareTo(new SimpleDateFormat("yyyy-MM-dd").parse((String) object.get("accessDate")))<1){
						accessDate=new SimpleDateFormat("yyyy-MM-dd").parse((String) object.get("accessDate"));
					}
				}
	    	}
	    		
			
			Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), object.get("created"));   
	    
	    }
	   
	    Assert.assertEquals(actualParticipantlist, dbParticipantList); 	  
	    Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(accessDate), new SimpleDateFormat("yyyy-MM-dd").format(regExpirationDate));
		String expirationDate= new SimpleDateFormat("yyyyMMddHHmmss").format(regExpirationDate);
		String date=expirationDate.substring(0,8);
		//Date expirationDateFormat=new SimpleDateFormat(storagePathSignature).parse(date);
		
		if(storageFolderLevel.equals("Hours")){
			repositoryFolder=storagePathPrefix+date+"/"+expirationDate.substring(8,10);
		}else if(storageFolderLevel.equals("Minutes")){
			repositoryFolder=storagePathPrefix+date+"/"+expirationDate.substring(8,10)+"/"+expirationDate.substring(10,12);
		}else if(storageFolderLevel.equals("Seconds")){
			repositoryFolder=storagePathPrefix+date+"/"+expirationDate.substring(8,10)+"/"+expirationDate.substring(10,12)+"/"+expirationDate.substring(12,14).toString();
		}
		Assert.assertEquals(regRepositoryFolder, repositoryFolder); 	  

	    
	    logger.info("Registrations_Participants table data validated successfully");		    
	    
	}
	
	public void reg_Replication_Validation() throws SQLException, InterruptedException{
		logger.info("Started REGISTRATIONS_REPLICATIONS table data validation");						
	    ResultSet rsRegReplication =stmt.executeQuery("select * from REGISTRATIONS_REPLICATIONS where registryId="+'\''+dbRegistryId+ '\''+"order by recordid asc");
	    
	    while(rsRegReplication.next())
	    	if(!contentType.equals("METADATA")){
	    		if(rsRegReplication.getString("REQUESTTYPE").equals("CreateRegistryEntry") || rsRegReplication.getString("REQUESTTYPE").equals("ContentServiceListener")){
	    			Assert.assertEquals(dbRegistryId, rsRegReplication.getString("REGISTRYID"));	    	        
	    		    Assert.assertEquals(originatingSite.toUpperCase(), rsRegReplication.getString("ORIGINATINGSITENAME"));
	    		    Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsRegReplication.getTimestamp(originatingSite.toUpperCase())));
	    		    Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsRegReplication.getTimestamp(replicationSite.toUpperCase())));    	        
	    		    Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsRegReplication.getTimestamp("CREATED"))); 
	    		    Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsRegReplication.getTimestamp("COMPLETED"))); 
	    		    Assert.assertNull(rsRegReplication.getString("OWNEDBY"));
	    		    Assert.assertNull(rsRegReplication.getString("ERROROCCURRED"));
	    		    Assert.assertEquals(true,rsRegReplication.getString("REPOSITORYFOLDER").contains(storagePathPrefix));
	    		    Assert.assertNull(rsRegReplication.getTimestamp("DELETED"));
	    		    Assert.assertNull(rsRegReplication.getTimestamp("DEPOTA"));
	    		    Assert.assertNull(rsRegReplication.getTimestamp("DEPOTB"));
	    		    Assert.assertEquals("{\"sequenceNumber\":\"1\",\"version\":\"1\"}",rsRegReplication.getString("UNIQUEINFO"));
	    		
	    		}
	    	}else{
	    		Assert.assertEquals("CreateRegistryEntry", rsRegReplication.getString("REQUESTTYPE"));	  
	    		Assert.assertEquals(dbRegistryId, rsRegReplication.getString("REGISTRYID"));	    	        
	    	    Assert.assertEquals(originatingSite.toUpperCase(), rsRegReplication.getString("ORIGINATINGSITENAME"));
	    	    Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsRegReplication.getTimestamp(originatingSite.toUpperCase())));
	    	    Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsRegReplication.getTimestamp(replicationSite.toUpperCase())));    	        
	    	    Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsRegReplication.getTimestamp("CREATED"))); 
	    	    Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsRegReplication.getTimestamp("COMPLETED"))); 
	    	    Assert.assertNull(rsRegReplication.getString("OWNEDBY"));
	    	    Assert.assertNull(rsRegReplication.getString("ERROROCCURRED"));
	    	    Assert.assertEquals(true,rsRegReplication.getString("REPOSITORYFOLDER").contains(storagePathPrefix));
	    	    Assert.assertNull(rsRegReplication.getTimestamp("DELETED"));
	    	    Assert.assertNull(rsRegReplication.getTimestamp("DEPOTA"));
	    	    Assert.assertNull(rsRegReplication.getTimestamp("DEPOTB"));
	    	    Assert.assertEquals("{\"sequenceNumber\":\"1\",\"version\":\"1\"}",rsRegReplication.getString("UNIQUEINFO"));
	    	
	    	}    	        
	        logger.info("REGISTRATIONS_REPLICATIONS table validated successfully");
	    
	}
	
	public void reg_ServicesToApply_Validation() throws SQLException, InterruptedException{
		if(location.equals("centralDataRepository") && !contentType.equals("METADATA")){
			logger.info("Started REGISTRATIONS_SERVICESTOAPPLY table data validation");		
			ResultSet rsRegContentService =stmt.executeQuery("select * from REGISTRATIONS_SERVICESTOAPPLY where registryId="+'\''+dbRegistryId+ '\'');
		    result=rsRegContentService.next();
		    Assert.assertTrue(result);
		    Assert.assertEquals("virusscan", rsRegContentService.getString("SERVICETYPE"));	
		    Assert.assertEquals("Originator", rsRegContentService.getString("REQUESTEDBY"));
		    Assert.assertEquals("Success", rsRegContentService.getString("STATUS"));
		    Assert.assertEquals("Requested", rsRegContentService.getString("REASON"));
		    Assert.assertEquals(dbRegistryId, rsRegContentService.getString("REGISTRYID"));	    	        
		    Assert.assertEquals(originatingSite.toUpperCase(), rsRegContentService.getString("TARGETUNIQUENAME"));
		    Assert.assertEquals("{\"sequenceNumber\":\"1\",\"version\":\"1\"}",rsRegContentService.getString("UNIQUEINFO"));
		    Assert.assertNotNull(rsRegContentService.getString("SERVICEID"));
		    Assert.assertNull(rsRegContentService.getString("OWNEDBY"));     
		    Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsRegContentService.getTimestamp("CREATED"))); 
		    Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsRegContentService.getTimestamp("REQUESTSENT"))); 
		    Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsRegContentService.getTimestamp("LASTPOLLED"))); 
		    Assert.assertEquals(new SimpleDateFormat("yyyy-MM-dd").format(currentDate), new SimpleDateFormat("yyyy-MM-dd").format(rsRegContentService.getTimestamp("COMPLETED"))); 
		    Assert.assertEquals("CSL", rsRegContentService.getString("COMPLETIONDETECTEDBY"));
		    logger.info("REGISTRATIONS_SERVICESTOAPPLY table content validated successfully");
		}
	    
	    logger.info("Database validation is completed");
	}
	
	public void validateOCSData(){
		JsonPath jsonPath=new JsonPath(responseBody);
		logger.info("Started validating OCSData");
		String decodedOcsData = new String(Base64.getDecoder().decode(jsonPath.getString("ocsData")));
		logger.info("OCS Data: "+decodedOcsData);
		Assert.assertEquals(true, decodedOcsData.contains("registryId"));
		Assert.assertEquals(true, decodedOcsData.contains("registryIdSignature"));
		Assert.assertEquals(true, decodedOcsData.contains("availableContent"));
		JsonPath ocsJSON = new JsonPath(decodedOcsData);
		Assert.assertEquals(dbRegistryId, ocsJSON.getString("registryId"));
		Assert.assertEquals(dbRegistryIdSignature, ocsJSON.getString("registryIdSignature"));
		if(expRegistryStatus.equals("Registered")){
			Assert.assertEquals(true, decodedOcsData.contains("registered"));
			//Assert.assertEquals(DBREGISTERED, oncsJSON.getString("registered"));
		}
		else{
			Assert.assertEquals(false, decodedOcsData.contains("registered"));
		}
        Assert.assertEquals(label,ocsJSON.get("availableContent[0].label"));
        Assert.assertEquals(contentType,ocsJSON.get("availableContent[0].type"));
        if(location.equals("centralDataRepository") && !contentType.equals("METADATA")){
        	 Assert.assertEquals(Integer.parseInt(size),ocsJSON.getInt("availableContent[0].size"));
             Assert.assertEquals(checkSum,ocsJSON.get("availableContent[0].checkSum"));
        }
        logger.info("OCSDATA validation is completed");
	}
	
 	@AfterMethod
	 public void CheckResults(ITestResult result) throws IOException {
		if (result.getStatus() == ITestResult.FAILURE) {
			childTest.log(Status.FAIL, "Test Step is FAILED due to below reason");
			childTest.log(Status.FAIL, result.getThrowable().fillInStackTrace()); // to add error/exception in extent report
			childTest.log(Status.FAIL, "Test Case ("+this.testName+") is FAILED");
		}
		else if (result.getStatus() == ITestResult.SKIP) {
			childTest.log(Status.SKIP, "Test Case ("+this.testName+") is SKIPPED");
		}
		else if (result.getStatus() == ITestResult.SUCCESS) {
			childTest.log(Status.PASS, "Test Case ("+this.testName+") is PASSED");
		}
	}
	
	@AfterTest
	 public void endReport() throws SQLException {		
		extent.flush();
		connObj1.close();
		connObj2.close();
		//connObj3.close();
	 }
			
	
	@DataProvider(name="CreateRegistryEntryTestData")
	String[][] CreateRegistryEntryTestData() throws IOException, ConfigException{
		String path=createRegistryTestData;
		int rowNum=XLUtils.getRowCount(path, "Sheet1");
		int colCount=XLUtils.getCellCount(path, "Sheet1", rowNum);
		String testData[][]=new String[rowNum][colCount];
		
		for (int i=1; i<=rowNum; i++){
			for (int j=0; j<colCount; j++){
				testData[i-1][j]=XLUtils.getCellData(path, "Sheet1", i, j);
			}
		}
				
		return(testData);		
	}
}
